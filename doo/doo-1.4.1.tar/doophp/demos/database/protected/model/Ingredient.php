<?php
class Ingredient{
    public $id;
    public $name;
    public $_table = 'ingredient';
    public $_primarykey = 'id';
    public $_fields = array('id','name');
}
?>