<?php
class FoodType{
    public $id;
    public $name;
    public $_table = 'food_type';
    public $_primarykey = 'id';
    public $_fields = array('id','name');
}
?>