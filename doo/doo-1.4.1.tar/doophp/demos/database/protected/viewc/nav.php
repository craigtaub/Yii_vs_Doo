        <a id="top" name="top"></a>
        <div class="top"><a href="javascript:smaller();">[-]</a><a href="javascript:larger();">[+]</a> <a href="http://doophp.com/demos">demo@doophp</a></div>
        <div class="header"><strong>Doophp </strong><span class="boldy">Database ORM </span> demo. Class used - <strong><span class="file"><a href="http://www.doophp.com/documentation/api/">DooSqlMagic</a></span></strong><br/>
      </div>
	  ...<br/>
	  <div class="nav">
	  	<ul>
			<li><a href="<?php echo $data['baseurl']; ?>index.php/about">About@</a></li>
			<li><a href="<?php echo $data['baseurl']; ?>index.php/url">URL Links@</a></li>
			<li><a href="<?php echo $data['baseurl']; ?>index.php/example">Example Usage@</a></li>
		</ul>
	  </div>