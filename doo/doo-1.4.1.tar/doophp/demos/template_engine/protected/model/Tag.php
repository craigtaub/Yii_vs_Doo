<?php

class Tag {
    var $name;
}
?>