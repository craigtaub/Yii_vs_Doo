<?php
class Blog {
    var $title;
    var $content;
    var $Tag;
}
?>