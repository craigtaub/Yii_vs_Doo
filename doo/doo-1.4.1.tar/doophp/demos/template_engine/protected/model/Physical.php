<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Physical
 *
 * @author leng
 */
class Physical {
    var $weight;
    var $height;
}
?>