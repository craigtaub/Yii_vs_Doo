<p>This is include file nested in sub folder.</p>
<pre>This is from a included template in a sub folder. view/nested/hi.html
Variable value: <?php echo $data['nested']; ?> </pre>