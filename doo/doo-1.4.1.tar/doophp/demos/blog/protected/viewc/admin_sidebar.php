        <h2>Admin</h2>
        <ul>
            <li>
                <a href="<?php echo $data['rootUrl']; ?>admin/post/">Manage Posts</a>
                <a href="<?php echo $data['rootUrl']; ?>admin/post/create">Create Post</a>
                <a href="<?php echo $data['rootUrl']; ?>admin/comment/">Approve Comments</a>
            </li>
        </ul>

        <br/>
        <script type="text/javascript"><!--
        google_ad_client = "pub-0119468645083312";
        google_ad_slot = "8043445324";
        google_ad_width = 120;
        google_ad_height = 600;
        //-->
        </script>
        <script type="text/javascript"
        src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
        </script>