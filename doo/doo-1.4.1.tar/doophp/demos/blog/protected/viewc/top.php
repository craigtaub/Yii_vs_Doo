<div id="header">
    <h1><a href="#">DooPHP Blog Demo</a></h1>
    <h2>Welcome to DooPHP Blog Demo! Have fun!</h2>
</div>

<div id="top"> </div>

<div id="menu">
    <ul>
    <li><a href="<?php echo $data['rootUrl']; ?>">Home</a></li>
    <li><a href="<?php echo $data['rootUrl']; ?>admin">Admin</a></li>
    <li><a href="http://doophp.com/forum">Discuss at forum</a></li>
    </ul>
</div>
