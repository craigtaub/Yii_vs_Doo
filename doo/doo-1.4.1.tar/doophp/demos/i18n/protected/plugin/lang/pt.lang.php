<?php
$lang['This can be translated'] = 'Isso pode ser traduzido';
$lang['This is a cool message.'] = 'Esta é uma boa mensagem.';
$lang['ERROR 404'] = 'Erro 404';
?>