<?php
$lang['welcome_user'] = 'Herzlich Willkommen auf meiner Seite, Herr User!';
$lang['input_invalid'] = 'Ungültige Eingabe für die E-Mail-Adresse.';
?>