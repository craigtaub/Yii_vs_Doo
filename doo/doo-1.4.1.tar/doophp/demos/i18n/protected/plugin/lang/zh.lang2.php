<?php
$lang['welcome_user'] = '欢迎光临我的网站, 用户先生!';
$lang['input_invalid'] = '电邮地址有错误!';
?>