<?php
$lang['This can be translated'] = '这可以被翻译';
$lang['This is a cool message.'] = '这是个很酷的信息。';
$lang['ERROR 404'] = '404错误';
?>