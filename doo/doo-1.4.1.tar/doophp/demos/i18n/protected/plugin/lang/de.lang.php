<?php
$lang['This can be translated'] = 'Dies kann übersetzt werden';
$lang['This is a cool message.'] = 'Dies ist eine coole Nachricht.';
$lang['ERROR 404'] = 'Fehler 404';
?>