<?php
$lang['welcome_user'] = 'Bem-vindo ao meu site, o Sr. Usuário!';
$lang['input_invalid'] = 'Entrada inválida para o endereço de email.';
?>