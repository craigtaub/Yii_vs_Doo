		<title>DooPHP - i18n Internationalization demo</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="description" content="DooPHP framework URI routing demo">
		<meta name="keywords" content="DooPHP, php framework, MVC, Web 2.0, design, xhtml, css, template">
		<link rel="stylesheet" type="text/css" href="<?php echo $data['baseurl']; ?>global/css/screen.css" media="screen" />
        <script type="text/javascript" src="<?php echo $data['baseurl']; ?>global/js/jquery.1.3.2.js"></script>
        <script type="text/javascript" src="<?php echo $data['baseurl']; ?>global/js/common.js"></script>