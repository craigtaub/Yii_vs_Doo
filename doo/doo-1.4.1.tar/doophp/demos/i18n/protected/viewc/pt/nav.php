        <a id="top" name="top"></a>
        <div class="top"><a href="javascript:smaller();">[-]</a><a href="javascript:larger();">[+]</a> <a href="http://doophp.com/demos">demo@doophp</a></div>
        <div class="header"><strong>Doophp </strong><span class="boldy">i18n</span> demo.
Classe utilizados - <strong><span class="file"><a href="http://www.doophp.com/documentation/api/">DooController</a></span></strong><br/>
      </div>

      <div style="float:right">
<a style="color:#fff;text-decoration:none;padding-right:20px;" href="<?php echo $data['baseurl']; ?>index.php/home/?lang=en">en</a>

<a style="color:#fff;text-decoration:none;padding-right:20px;" href="<?php echo $data['baseurl']; ?>index.php/home/?lang=zh">cn</a>

<a style="color:#fff;text-decoration:none;padding-right:20px;" href="<?php echo $data['baseurl']; ?>index.php/home/?lang=pt">pt</a>

<a style="color:#fff;text-decoration:none;padding-right:20px;" href="<?php echo $data['baseurl']; ?>index.php/home/?lang=de">de</a>
</div>
	  ...<br/>
	  <div class="nav">
	  	<ul>
			<li><a href="<?php echo $data['baseurl']; ?>index.php/about">Sobre@</a></li>
			<li><a href="<?php echo $data['baseurl']; ?>index.php/example">Exemplo de Uso@</a></li>
		</ul>
	  </div>